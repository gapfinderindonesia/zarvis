#!/bin/bash

pkg install screenfetch -y
pkg install termux-api
